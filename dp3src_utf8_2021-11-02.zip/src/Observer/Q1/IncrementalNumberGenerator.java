// IncrementalNumberGeneratorクラスを実装してください。
