// FilePropertiesクラスを実装してください。
