// UpDownBorderクラスを実装してください。
