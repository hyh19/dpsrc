// MultiStringDisplayクラスを実装してください。
