public class Main {
    public static void main(String[] args) {
        String html = """
        <!DOCTYPE html>
        <html>
            <head>
                <title>Welcome!</title>
            </head>
            <body>
                <h1 style="text-align: center">Hello, world!</h1>
            </body>
        </html>
        """;
        System.out.print(html);
    }
}
